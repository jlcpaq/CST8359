﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;
using System.IO.Enumeration;

IList<string> words = new List<string>();
String userInput = "";
var watch = Stopwatch.StartNew();
watch.Stop();
while (userInput != "x") {

    Console.WriteLine("1 - Import words from File");
    Console.WriteLine("2 - Bubble sort words");
    Console.WriteLine("3 - LINQ/Lambda sort words");
    Console.WriteLine("4 - Count the distinct words");
    Console.WriteLine("5 - Take the first 50 words");
    Console.WriteLine("6 - Reverse print the words");
    Console.WriteLine("7 - Get and display words that end with ‘a’ and display the count");
    Console.WriteLine("8 - Get and display words that include ‘m’ and display the count");
    Console.WriteLine("9 - Get and display words that are less than 4 characters long and include the letter ‘I’, and display the count");
    Console.WriteLine("x - Exit");
    Console.Write("Select an option: ");

    userInput = Console.ReadLine();
    switch (userInput) {
        case "1":
            ImportFromFile();
            Console.WriteLine("The number of words is " + words.Count);
            break;
        case "2":
            watch = Stopwatch.StartNew();
            bubbleSort(words);
            watch.Stop();
            Console.WriteLine("Execution time: " + watch.ElapsedMilliseconds + " ms");
            break;
        case "3":
            watch = Stopwatch.StartNew();
            LINQSort(words);
            watch.Stop();
            Console.WriteLine("Execution time: " + watch.ElapsedMilliseconds + " ms");
            break;
        case "4":
            int numWords = DistinctWords(words);
            Console.WriteLine("Distinct Count is " + numWords);
            break;
        case "5":
            First50(words);
            break;
        case "6":
            PrintReverse(words);
            break;
        case "7":
            EndInA(words);
            break;
        case "8":
            ContainsM(words);
            break;
        case "9":
            ContainsI(words);
            break;
        case "x":
            Environment.Exit(0);
            break;

    }
}


void ImportFromFile() {
    string filePath = "C:\\Users\\jlcpa\\Downloads\\Lab1Demo\\Words.txt";
    try
    {
        using (StreamReader streamReader = new StreamReader(filePath)) {
                string line;

                while ((line = streamReader.ReadLine()) != null) { 
                    words.Add(line);
                }
        }
    
    } catch (Exception e)
        {
        
        Console.WriteLine("The file could not be read:");
        Console.WriteLine(e.Message);
    }


}

void bubbleSort(IList<string> words) {
    
    bool swapped;

    IList<string> list = words.ToList();
    int wordCount = list.Count;

    int i, j;
    string temp;
    for (i = 0; i < wordCount - 1; i++) {
        swapped = false;
        for (j = 0; j < wordCount - i - 1; j++) { 
            if (list[j].CompareTo(list[j + 1]) > 0 ) {
                    temp = list[j];
                    list[j] = list[j + 1];
                    list[j + 1] = temp;
                    swapped = true;

                }
        }

        if (swapped == false)
            break;
            
    }

}

void LINQSort(IList<string> words) {

    IList<string> list = words;

    IList<string> sorted = list.OrderBy(word => word).ToList();

}


int DistinctWords(IList<string> words) {

    IList<string> distinct = words.Distinct().ToList();

    int count = distinct.Count();

    return count;
}

void First50(IList<string> words)
{
    IList<string> sorted = words.Take(50).ToList();

    foreach (string word in sorted)
    {
        Console.WriteLine(word);
    }
}

void PrintReverse(IList<string> words) {
    IList<string> list = words.Reverse().ToList();

    foreach (string word in list)
    {
        Console.WriteLine(word);
    }
}

void EndInA(IList<string> words) { 
 
    IList<string> list = words.Where(word => word.EndsWith("a")).ToList();
    
    Console.WriteLine("Word Count is " + list.Count());

    foreach (string word in list) {
        Console.WriteLine(word);
    }
}

void ContainsM(IList<string> words) {
    IList<string> list = words.Where(word => word.Contains("m")).ToList();
   
    Console.WriteLine("Word Count is " + list.Count());

    foreach (string word in list)
    {
        Console.WriteLine(word);
    }

}

void ContainsI(IList<string> words) {
    IList<string> list = words.Where(word => word.Contains("i") && word.Length < 4).ToList();

    Console.WriteLine("Word Count is " + list.Count());

    foreach (string word in list)
    {
        Console.WriteLine(word);
    }
}